"""
Gerenciamento de favoritos com persistência e auditoria.
Suporta formato antigo e novo, gravação atômica.
"""

import asyncio
import logging
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Optional, List
from datetime import datetime

from utils.formatting import format_timestamp
from utils.persistence import atomic_read_json, atomic_write_json, atomic_write_csv_line
from utils.errors import FavoriteNotFoundError, InvalidFavoriteError
from config import settings


logger = logging.getLogger(__name__)


@dataclass
class Favorite:
    """Favorito individual."""
    url: str
    title: str
    added_by: str
    added_by_id: int
    added_at: str  # ISO format
    
    def to_dict(self) -> dict:
        return asdict(self)
    
    @classmethod
    def from_dict(cls, data: dict) -> "Favorite":
        """Carrega favorito do dict (compatível com formato antigo)."""
        return cls(
            url=data.get("url", ""),
            title=data.get("title", ""),
            added_by=data.get("added_by", "Desconhecido"),
            added_by_id=data.get("added_by_id", 0),
            added_at=data.get("added_at", format_timestamp()),
        )


class FavoritesManager:
    """Gerencia favoritos com persistência."""
    
    def __init__(self, data_dir: Path):
        self.data_dir = Path(data_dir)
        self.favorites_file = self.data_dir / "favorites.json"
        self.audit_file = self.data_dir / "favorites_audit.csv"
        self.lock = asyncio.Lock()
        self._favorites: List[Favorite] = []
        self._load_sync()
    
    def _load_sync(self) -> None:
        """Carrega favoritos de forma síncrona (inicialização)."""
        try:
            data = atomic_read_json(self.favorites_file, default=[])
            
            # Compatibilidade com formato antigo
            if isinstance(data, dict) and "favorites" in data:
                data = data["favorites"]
            
            # Converte para objetos Favorite
            self._favorites = [
                Favorite.from_dict(item) if isinstance(item, dict) else item
                for item in (data or [])
            ]
            
            logger.info(f"✓ Carregados {len(self._favorites)} favoritos")
        
        except Exception as e:
            logger.error(f"Erro ao carregar favoritos: {e}")
            self._favorites = []
    
    async def add(
        self,
        url: str,
        title: str,
        added_by: str,
        added_by_id: int,
        guild_id: int,
    ) -> int:
        """
        Adiciona novo favorito.
        
        Args:
            url: URL da música/playlist.
            title: Título.
            added_by: Nome de quem adicionou.
            added_by_id: ID do usuário Discord.
            guild_id: ID do servidor.
            
        Returns:
            Índice do novo favorito (1-based).
            
        Raises:
            InvalidFavoriteError: Se dados inválidos.
        """
        async with self.lock:
            favorite = Favorite(
                url=url,
                title=title,
                added_by=added_by,
                added_by_id=added_by_id,
                added_at=format_timestamp(),
            )
            
            self._favorites.append(favorite)
            
            # Persiste
            self._save_sync()
            
            # Auditoria
            index = len(self._favorites)
            self._audit_sync(
                action="ADD",
                title=title,
                url=url,
                user_name=added_by,
                user_id=added_by_id,
                guild_id=guild_id,
            )
            
            logger.info(f"✓ Favorito adicionado (#{index}): {title}")
            return index
    
    async def remove(self, index: int, guild_id: int) -> Favorite:
        """
        Remove favorito.
        
        Args:
            index: Índice do favorito (1-based).
            guild_id: ID do servidor.
            
        Returns:
            Favorito removido.
            
        Raises:
            FavoriteNotFoundError: Se índice inválido.
        """
        async with self.lock:
            if index < 1 or index > len(self._favorites):
                raise FavoriteNotFoundError(index)
            
            favorite = self._favorites.pop(index - 1)
            
            # Persiste
            self._save_sync()
            
            # Auditoria
            self._audit_sync(
                action="REM",
                title=favorite.title,
                url=favorite.url,
                user_name="",
                user_id=0,
                guild_id=guild_id,
            )
            
            logger.info(f"✓ Favorito removido (#{index}): {favorite.title}")
            return favorite
    
    async def get(self, index: int) -> Favorite:
        """
        Obtém favorito.
        
        Args:
            index: Índice (1-based).
            
        Returns:
            Favorito.
            
        Raises:
            FavoriteNotFoundError: Se inválido.
        """
        if index < 1 or index > len(self._favorites):
            raise FavoriteNotFoundError(index)
        
        return self._favorites[index - 1]
    
    async def list_all(self) -> List[Favorite]:
        """Retorna todos os favoritos."""
        return self._favorites.copy()
    
    async def search(self, query: str) -> List[tuple[int, Favorite]]:
        """
        Busca favoritos por título.
        
        Args:
            query: Termo de busca.
            
        Returns:
            Lista de (índice, favorito) encontrados.
        """
        query = query.lower()
        results = [
            (i + 1, fav)
            for i, fav in enumerate(self._favorites)
            if query in fav.title.lower()
        ]
        return results
    
    def _save_sync(self) -> None:
        """Salva favoritos (thread-safe)."""
        try:
            data = [fav.to_dict() for fav in self._favorites]
            atomic_write_json(self.favorites_file, data)
            logger.debug(f"Favoritos salvos ({len(self._favorites)} itens)")
        except Exception as e:
            logger.error(f"Erro ao salvar favoritos: {e}")
            raise
    
    def _audit_sync(
        self,
        action: str,
        title: str,
        url: str,
        user_name: str,
        user_id: int,
        guild_id: int,
    ) -> None:
        """Registra auditoria."""
        try:
            timestamp = format_timestamp()
            atomic_write_csv_line(
                self.audit_file,
                [timestamp, action, title, url, user_name, str(user_id), str(guild_id)],
            )
        except Exception as e:
            logger.error(f"Erro ao registrar auditoria: {e}")


# Instância global (inicializada em bot.py)
favorites_manager: Optional[FavoritesManager] = None


def init_favorites(data_dir: Path) -> FavoritesManager:
    """Inicializa gerenciador de favoritos."""
    global favorites_manager
    favorites_manager = FavoritesManager(data_dir)
    return favorites_manager
