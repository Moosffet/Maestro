"""Utils package."""

from utils.logging import setup_logging, get_logger
from utils.errors import (
    BotError,
    YouTubeError,
    PlayerError,
    DiscordError,
    FavoritesError,
    ConfigError,
)
from utils.formatting import (
    format_duration,
    parse_duration,
    is_youtube_url,
    is_playlist_url,
    extract_video_id,
    truncate,
)
from utils.validation import (
    validate_index,
    validate_volume,
    validate_url,
    validate_search_query,
)
from utils.persistence import (
    atomic_write_json,
    atomic_read_json,
    atomic_write_csv_line,
)

__all__ = [
    "setup_logging",
    "get_logger",
    "BotError",
    "YouTubeError",
    "PlayerError",
    "DiscordError",
    "FavoritesError",
    "ConfigError",
    "format_duration",
    "parse_duration",
    "is_youtube_url",
    "is_playlist_url",
    "extract_video_id",
    "truncate",
    "validate_index",
    "validate_volume",
    "validate_url",
    "validate_search_query",
    "atomic_write_json",
    "atomic_read_json",
    "atomic_write_csv_line",
]
